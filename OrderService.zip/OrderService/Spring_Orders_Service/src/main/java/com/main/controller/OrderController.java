package com.main.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.main.Feign.ProductFiengn;
import com.main.model.Order;
import com.main.model.Product;
import com.main.service.OrderServiceIntf;

@RestController
@RequestMapping("/order")
public class OrderController {

	@Autowired
	private OrderServiceIntf orderService;
	@Autowired
	private ProductFiengn productFeignClient;

	@PostMapping("/saveOrder")
	public ResponseEntity<String> saveOrder(@RequestBody Order order) {
		orderService.saveOrderDetails(order);
		return new ResponseEntity<String>("Order Added Successfully", HttpStatus.CREATED);
	}

	@GetMapping("/getOrderDetails")
	public ResponseEntity<List<Order>> fetchDataOrder() {
		List<Order> list = orderService.fetchProductData();
		if (list.size() == 0) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@GetMapping("/orderDetails/{orderId}")
	public ResponseEntity<Order> buyOrderUsingId(@PathVariable("orderId") int orderId) {
		Order order = orderService.buyUsingOrderId(orderId).get();
		if (order != null)
			return new ResponseEntity<>(order, HttpStatus.OK);
		else
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	}

	@GetMapping("/totalCalculate/{orderId}")
	public double getTotalAmount(@PathVariable("orderId") int orderId) {
		Order order = orderService.buyUsingOrderId(orderId).get();
		Product product = productFeignClient.buyUsingId(order.getProductId()).getBody();
		double totalAmount = ((product.getPrice()) * (order.getQuantity()));
		System.out.println(totalAmount);
		return totalAmount;
	}
}
