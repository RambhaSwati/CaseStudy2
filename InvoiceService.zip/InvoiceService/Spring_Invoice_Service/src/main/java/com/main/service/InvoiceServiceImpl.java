package com.main.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.main.dao.InvoicePARepository;
import com.main.model.Invoice;

@Service
@Transactional
public class InvoiceServiceImpl implements InvoiceServiceIntf {
	@Autowired
	InvoicePARepository invoiceRepo;

	public void saveInvoiceDetails(Invoice invoice, double totalAmount) {
		invoice.setTotalAmount(totalAmount);
		invoiceRepo.save(invoice);
	}

}