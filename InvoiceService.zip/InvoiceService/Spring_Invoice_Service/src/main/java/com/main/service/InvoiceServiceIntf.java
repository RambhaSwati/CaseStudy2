package com.main.service;

import com.main.model.Invoice;

public interface InvoiceServiceIntf {

	void saveInvoiceDetails(Invoice invoice, double totalAmount);

}